# wordcount
Take a file and counts the number of times a word occurs within a text file. Give script an initial argument (*.txt file) before running.
After running, type a word you want to count, hit enter.
